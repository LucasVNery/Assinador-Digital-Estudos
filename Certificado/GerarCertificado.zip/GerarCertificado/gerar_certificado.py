"""
Geração de Certificado Digital Simulado - ICP-Brasil (Educacional)
==================================================================
Este script gera um par de chaves RSA e um certificado X.509 simulado
em conformidade com os padrões da ICP-Brasil, para fins educacionais.

AVISO: Este certificado NÃO é válido para uso em produção.
Para certificados reais, contate uma AC credenciada pela ICP-Brasil.
"""

from cryptography import x509
from cryptography.x509.oid import NameOID
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.hazmat.backends import default_backend
import datetime
import os
import getpass

# ─────────────────────────────────────────────
# CONFIGURAÇÕES — ajuste conforme necessário
# ─────────────────────────────────────────────
KEY_SIZE        = 4096         # Tamanho da chave RSA em bits
PUBLIC_EXPONENT = 65537        # Expoente público padrão

COUNTRY       = "BR"
STATE         = "Tocantins"
LOCALITY      = "Palmas"
ORGANIZATION  = "Organização Simulada da Ulbra"
COMMON_NAME   = "Usuário ICP-Brasil"
EMAIL         = "usuario@simulado.br"

KEY_FILE  = "private_key.pem"
CERT_FILE = "certificate.pem"


def gerar_chave_privada(key_size: int = KEY_SIZE) -> rsa.RSAPrivateKey:
    """Gera um par de chaves RSA com o tamanho especificado."""
    print(f"[1/3] Gerando par de chaves RSA ({key_size} bits)...")
    chave = rsa.generate_private_key(
        public_exponent=PUBLIC_EXPONENT,
        key_size=key_size,
        backend=default_backend()
    )
    print("      Par de chaves gerado com sucesso.")
    return chave


def gerar_certificado(chave_privada: rsa.RSAPrivateKey) -> x509.Certificate:
    """Cria um certificado X.509 autoassinado com dados da ICP-Brasil simulados."""
    print("[2/3] Criando certificado X.509...")

    nome = x509.Name([
        x509.NameAttribute(NameOID.COUNTRY_NAME,             COUNTRY),
        x509.NameAttribute(NameOID.STATE_OR_PROVINCE_NAME,   STATE),
        x509.NameAttribute(NameOID.LOCALITY_NAME,            LOCALITY),
        x509.NameAttribute(NameOID.ORGANIZATION_NAME,        ORGANIZATION),
        x509.NameAttribute(NameOID.COMMON_NAME,              COMMON_NAME),
        x509.NameAttribute(NameOID.EMAIL_ADDRESS,            EMAIL),
    ])

    agora     = datetime.datetime.now(datetime.timezone.utc)
    expiracao = agora + datetime.timedelta(days=365)

    certificado = (
        x509.CertificateBuilder()
        .subject_name(nome)
        .issuer_name(nome)
        .public_key(chave_privada.public_key())
        .serial_number(x509.random_serial_number())
        .not_valid_before(agora)
        .not_valid_after(expiracao)
        .add_extension(
            x509.BasicConstraints(ca=False, path_length=None),
            critical=True
        )
        .add_extension(
            x509.KeyUsage(
                digital_signature=True,
                content_commitment=True,
                key_encipherment=False,
                data_encipherment=False,
                key_agreement=False,
                key_cert_sign=False,
                crl_sign=False,
                encipher_only=False,
                decipher_only=False
            ),
            critical=True
        )
        .add_extension(
            x509.SubjectAlternativeName([
                x509.RFC822Name(EMAIL)
            ]),
            critical=False
        )
        .sign(chave_privada, hashes.SHA256(), default_backend())
    )

    print("      Certificado criado com sucesso!")
    return certificado


def salvar_arquivos(chave_privada: rsa.RSAPrivateKey,
                    certificado: x509.Certificate) -> None:
    """Salva a chave privada protegida por senha e o certificado em arquivos PEM."""
    print("[3/3] Salvando arquivos .PEM ...")


    while True:
        senha = getpass.getpass("      Digite a senha para proteger a chave privada: ")

        erros = []

        if len(senha) < 8:
            erros.append("Pelo menos 8 caracteres")
        if not any(c.isupper() for c in senha):
            erros.append("Pelo menos 1 letra maiúscula (A-Z)")
        if not any(c.islower() for c in senha):
            erros.append("Pelo menos 1 letra minúscula (a-z)")
        if not any(c.isdigit() for c in senha):
            erros.append("Pelo menos 1 número (0-9)")
        if not any(c in "!@#$%^&*()_+-=[]{}|;:,.<>?/~`" for c in senha):
            erros.append("Pelo menos 1 caractere especial (!@#$%^&*...)")

        if erros:
            print("      ERRO: A senha não atende aos requisitos:")
            for erro in erros:
                print(f"        - {erro}")
            print()
            continue

        confirmacao = getpass.getpass("      Confirme a senha: ")

        if senha != confirmacao:
            print("      ERRO: As senhas não coincidem. Tente novamente.\n")
            continue

        break

    with open(KEY_FILE, "wb") as f:
        f.write(chave_privada.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.TraditionalOpenSSL,
            encryption_algorithm=serialization.BestAvailableEncryption(senha.encode())
        ))
    os.chmod(KEY_FILE, 0o600)
    print(f"      Chave privada salva em: {KEY_FILE}  (protegida por senha, permissão 600)")

    with open(CERT_FILE, "wb") as f:
        f.write(certificado.public_bytes(serialization.Encoding.PEM))
    print(f"      Certificado  salvo em: {CERT_FILE}")


def exibir_resumo(certificado: x509.Certificate) -> None:
    """Exibe um resumo legível do certificado gerado."""

    def extrair_campo(nome, oid):
        try:
            return nome.get_attributes_for_oid(oid)[0].value
        except IndexError:
            return "Não informado"

    sujeito = certificado.subject
    print("\n" + "="*55)
    print("  RESUMO DO CERTIFICADO GERADO")
    print("="*55)
    print(f"  O Emissor especificamente foi omitido porque, como o certificado é autoassinado, ele é sempre idêntico ao Sujeito.")
    print(f"  País           : {extrair_campo(sujeito, NameOID.COUNTRY_NAME)}")
    print(f"  Estado         : {extrair_campo(sujeito, NameOID.STATE_OR_PROVINCE_NAME)}")
    print(f"  Cidade         : {extrair_campo(sujeito, NameOID.LOCALITY_NAME)}")
    print(f"  Organização    : {extrair_campo(sujeito, NameOID.ORGANIZATION_NAME)}")
    print(f"  Nome comum     : {extrair_campo(sujeito, NameOID.COMMON_NAME)}")
    print(f"  E-mail         : {extrair_campo(sujeito, NameOID.EMAIL_ADDRESS)}")
    print("-"*55)
    print(f"  Número de série: {certificado.serial_number}")
    print(f"  Válido de      : {certificado.not_valid_before_utc.strftime('%d/%m/%Y %H:%M:%S')} UTC")
    print(f"  Válido até     : {certificado.not_valid_after_utc.strftime('%d/%m/%Y %H:%M:%S')} UTC")
    print(f"  Algoritmo      : {certificado.signature_hash_algorithm.name.upper()}")
    print("="*55)
    print("\nAviso: certificado gerado apenas para fins educacionais.")

if __name__ == "__main__":
    print("\n=== Gerador de Certificado Digital Simulado (ICP-Brasil) ===\n")
    chave = gerar_chave_privada()
    cert  = gerar_certificado(chave)
    salvar_arquivos(chave, cert)
    exibir_resumo(cert)